import tkinter.messagebox
from tkinter import *
from tkinter import Toplevel
from tkinter.ttk import *
#import sqlite3
from PIL import ImageTk
import mysql.connector

root = Tk()

def save_data():
    global  zero
    third.withdraw()
    name = ent1.get()
    pas = ent2.get()
    em = ent3.get()
    a = ent4.get()
    mydb = mysql.connector.connect(
      host="localhost",
      user="root",
      password="Shraddha@2004",
      database="user")
    mycursor = mydb.cursor()
    try:
        query = "INSERT INTO user(Username,Password,Email,Age)VALUES(?,?,?,?)"
        val = (name, pas, em, a)
        count = mycursor.execute("INSERT INTO user(Username,Password,Email,Age)VALUES(%s,%s,%s,%s)",val)
        mydb.commit()


        tkinter.messagebox.showinfo("SIGN UP", "Your data is successfully inserted.")
        global on
        on = Toplevel()
        on.geometry("250x250")
        Checkbutton(on, text="Do you really want to sign ").pack()
        Button(on, text="SIGN UP", command=win11).place(x=100, y=150, width=60, height=40)


    except Exception as e:
        print(e)

def data_rel():
    global oneo
    fourth.withdraw();
    n = ent5.get()
    p = ent6.get()
    mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Shraddha@2004",
    database="user")
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM user WHERE Username=%s AND Password=%s", (n, p))
    result = mycursor.fetchall()
    if len(result) > 0:
        tkinter.messagebox.showinfo("SIGN IN","Login Succesful")
        fourth.withdraw()
        oneo = Toplevel()
        oneo.geometry("900x500")
        im1=ImageTk.PhotoImage(file="logo11.jpg")
        Label(oneo, image=im1).pack()
        Checkbutton(oneo, text="ARE YOU REALLY WANT TO BE SIGN IN?").place(x=400,y=50)
        Button(oneo, text="SIGN IN", command=win112).place(x=450, y=100, width=100,height=40)
        #conn.close()
        oneo.mainloop()
        
    else:
        tkinter.messagebox.showinfo("SIGN IN","Incorrect username password.")
        win11()


#root Window
# calling first window
def lanuch():
    root.withdraw()
    global first
    first = Toplevel()
    first.title("logo window")
    first.geometry("500x600")
    a = ImageTk.PhotoImage(file="Shopkeeper.png")
    b = ImageTk.PhotoImage(file="Customer.png")
    l1 = Label(first, text="Shopkeeper", font=("BOLD", 20))
    l1.grid(row=0, column=1)
    l2 = Label(first, text="Customer", font=("BOLD", 20))
    l2.grid(row=1, column=0)
    btn1 = Button(first, text="Shopkeeper", image=a)
    btn1.grid(row=0, column=0)
    btn2 = Button(first, text="Customer", image=b,command=win14)
    btn2.grid(row=1, column=1)
    first.mainloop()
    
photo = ImageTk.PhotoImage(file="logo2.jpg")
Button(root, text="Hello", image=photo, command=lanuch).pack()

# customer sign in sign up window
def win14():
    first.withdraw()
    global second
    second = Toplevel()
    second.geometry("500x350")
    image7 = ImageTk.PhotoImage(file="logo5.jpg")
    Label(second, image=image7).pack()
    Button(second, text="SIGN UP",command=win3).place(x=200, y=150, width=100, height=40)
    Button(second, text="SIGN IN",command=win11).place(x=200, y=200, width=100, height=40)
    second.mainloop()

#Sign up Page
def win3():
    second.withdraw()
    global third
    global ent1, ent2, ent3, ent4
    third = Toplevel()
    third.title("Customer window")
    third.geometry("1000x500")
    image4 = ImageTk.PhotoImage(file="logo4.jpg")
    Label(third, image=image4).pack()
    Label(third, text="CUSTOMER LOGIN ", font=" ariel 24 bold").pack()
    Label(third, text="Username =", font="ariel 16 bold").place(x=300, y=150)
    ent1 = Entry(third, font="13")
    ent1.place(x=450, y=150)
    Label(third, text="Password =", font="ariel 16 bold").place(x=300, y=200)
    ent2 = Entry(third, font="13")
    ent2.place(x=450, y=200)
    Label(third, text="Email =", font="ariel 16 bold").place(x=300, y=250)
    ent3 = Entry(third, font="13")
    ent3.place(x=450, y=250)
    Label(third, text="Age=", font="ariel 16 bold").place(x=300, y=300)
    ent4 = Entry(third, font="13")
    ent4.place(x=450, y=300)
    Button(third, text="SIGN UP",command=save_data).place(x=450, y=350)
    Button(third, text="Back",command=win14).place(x=450, y=400)
    third.mainloop()

#Sign in page
def win11():
    second.withdraw()
    global fourth
    global ent5, ent6
    fourth = Toplevel()
    fourth.geometry("1000x500")
    image7 = ImageTk.PhotoImage(file="logo4.jpg")
    Label(fourth, image=image7).pack()
    Label(fourth, text="Username=").place(x=200, y=150, width=100, height=40)
    ent5 = Entry(fourth, font="13")
    ent5.place(x=300, y=150)
    Label(fourth, text="Password=").place(x=200, y=200, width=100, height=40)
    ent6 = Entry(fourth, font="13")
    ent6.place(x=300, y=200)
    Button(fourth, text="SIGN IN",command=data_rel).place(x=300, y=350, width=80, height=40)
    fourth.mainloop()

#Product display window
def win112():
    oneo.withdraw()
    global fifth
    fifth = Toplevel()
    fifth.title(" Product window")
    fifth.geometry("1000x700")
    # ima = ImageTk.PhotoImage(file="fresh.png")
    ima1 = ImageTk.PhotoImage(file="fresh1.png")
    ima2 = ImageTk.PhotoImage(file="fresh2.png")
    ima3 = ImageTk.PhotoImage(file="fresh3.png")
    l1 = Button(fifth, image=ima1,command=win113)
    l1.grid(row=10, column=1)
    l2 = Button(fifth, image=ima2,command=win114)
    l2.grid(row=10, column=2)
    l3 = Button(fifth, image=ima3,command=win115)
    l3.grid(row=10, column=3)
    fifth.mainloop()

#Fruits window
def win113():
    global img1, img2, img3, img4, img5, img6,sixth
    fifth.withdraw();
    sixth=Toplevel()
    sixth.title("Data")
    sixth.geometry("1000x700")
    img1 = ImageTk.PhotoImage(file="apple.png")
    img2 = ImageTk.PhotoImage(file="banana.png")
    img3 = ImageTk.PhotoImage(file="strawberry.png")
    img4 = ImageTk.PhotoImage(file="watermelon.png")
    img5 = ImageTk.PhotoImage(file="Pineapple.png")
    img6 = ImageTk.PhotoImage(file="Orange.png")
    b1 = Button(sixth, image=img1,command=lambda :win21(1))
    b2 = Button(sixth, image=img2,command=lambda :win21(2))
    b3 = Button(sixth, image=img3,command=lambda :win21(3))
    b4 = Button(sixth, image=img4,command=lambda :win21(4))
    b5 = Button(sixth, image=img5,command=lambda :win21(5))
    b6 = Button(sixth, image=img6,command=lambda :win21(6))
    Button(sixth, text="<-",command=win112).place(x=10, y=10, width=59, height=50)

    b1.place(x=300, y=100)
    b2.place(x=50, y=100)
    b3.place(x=50, y=400)
    b4.place(x=300, y=400)
    b5.place(x=570, y=100)
    b6.place(x=570, y=400)
    sixth.mainloop()

#Vegetables window
def win114():
    global img1, img2, img3, img4, img5, img6,seventh
    fifth.withdraw();
    seventh=Toplevel()
    seventh.title("Data")
    seventh.geometry("1000x700")
    img1 = ImageTk.PhotoImage(file="potato.png")
    img2 = ImageTk.PhotoImage(file="Tomato.png")
    img3 = ImageTk.PhotoImage(file="carrot.png")
    img4 = ImageTk.PhotoImage(file="eggplant.png")
    img5 = ImageTk.PhotoImage(file="muli.png")
    img6 = ImageTk.PhotoImage(file="Lockey.png")
    b1 = Button(seventh, image=img1)
    b2 = Button(seventh, image=img2)
    b3 = Button(seventh, image=img3)
    b4 = Button(seventh, image=img4)
    b5 = Button(seventh, image=img5)
    b6 = Button(seventh, image=img6)
    Button(seventh, text="<-",command=win112).place(x=10, y=10, width=59, height=50)

    b1.place(x=300, y=100)
    b2.place(x=50, y=100)
    b3.place(x=50, y=400)
    b4.place(x=300, y=400)
    b5.place(x=570, y=100)
    b6.place(x=570, y=400)
    seventh.mainloop()

#Green vegetables window
def win115():
    global img1, img2, img3, img4, img5, img6,eighth
    fifth.withdraw();
    eighth=Toplevel()
    eighth.title("Data")
    eighth.geometry("1000x1500")
    img1 = ImageTk.PhotoImage(file="Spinach.png")
    img2 = ImageTk.PhotoImage(file="Cabbage.png")
    img3 = ImageTk.PhotoImage(file="cauliflower.png")
    img4 = ImageTk.PhotoImage(file="Capsicum.png")
    img5 = ImageTk.PhotoImage(file="coriander.png")
    img6 = ImageTk.PhotoImage(file="methi.png")
    b1 = Button(eighth, image=img1)
    b2 = Button(eighth, image=img2)
    b3 = Button(eighth, image=img3)
    b4 = Button(eighth, image=img4)
    b5 = Button(eighth, image=img5)
    b6 = Button(eighth, image=img6)
    Button(eighth, text="<-",command=win112).place(x=10, y=10, width=59, height=50)

    b1.place(x=300, y=100)
    b2.place(x=50, y=100)
    b3.place(x=50, y=400)
    b4.place(x=300, y=400)
    b5.place(x=570, y=100)
    b6.place(x=570, y=400)
    eighth.mainloop()


def win21(b1):
    sixth.withdraw()
    global b2, b33, b44,img1,img2,img3,img4,img5,img6,Stock,Price,nineth
    nineth = Toplevel()
        #one.title(" Product window")
    nineth.geometry("500x650")
    if b1 == 1:
        img1 = ImageTk.PhotoImage(file="apple.png")
        b1 = Label(nineth, image=img1)
        btn = Button(nineth, image=img1)
        b1 = Button(sixth, image=img1)
        btn.place(x=50, y=50)
        global stock1,price1
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    elif b1 == 2:
        b1 = Label(nineth, image=img2)
        img2 = ImageTk.PhotoImage(file="banana.png")
        btn= Button(nineth, image=img2)
        btn.place(x=50, y=50)
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    elif b1 == 3:
        b1 = Label(nineth, image=img3)
        img3 = ImageTk.PhotoImage(file="strawberry.png")
        btn= Button(nineth, image=img3)
        btn.place(x=50, y=50)
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    elif (b1 == 4):
        b1 = Label(nineth, image=img4)
        img4 = ImageTk.PhotoImage(file="watermelon.png")
        btn= Button(nineth, image=img4)
        btn.place(x=50, y=50)
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    elif (b1 == 5):
        b1 = Label(nineth, image=img5)
        img5 = ImageTk.PhotoImage(file="pineapple.png")
        btn= Button(nineth, image=img5)
        btn.place(x=50, y=50)
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    elif (b1 == 6):
        b1 = Label(nineth, image=img6)
        img6 = ImageTk.PhotoImage(file="orange.png")
        btn= Button(nineth, image=img6)
        btn.place(x=50, y=50)
        stock1=50
        price1=50
        Label(nineth,text="Stock").place(x=150,y=300)
        Label(nineth,text="Price").place(x=150,y=350)
        Label(nineth,text=50).place(x=250,y=300)
        Label(nineth,text=50).place(x=250,y=350)
        b4 = Label(nineth, text="Quantity")
        b4.place(x=150,y=400)
        b44 = Entry(nineth)
        b44.place(x=150,y=450)
        b5 = Button(nineth, text="Order", command=lambda: win23(b1))
        b5.place(x=150,y=500)
    Button(nineth, text="<-",command=win113).place(x=10, y=5, width=59, height=40)
   
def win23(b1):
    tkinter.messagebox.showinfo("Bill","Order is placed. :")
        
