Create database User;
use User;
CREATE TABLE User(
  Username VARCHAR(100),
  Password VARCHAR(100),
  Email VARCHAR(100),
  Age int
);
select * from User;